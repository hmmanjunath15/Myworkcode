import { Component, OnInit,Input} from '@angular/core';
// import countries from './files/countries.json';
// import manju from './files/manju.json'
import parentdatajson from './parentdata.json'
import { Routes, RouterModule } from '@angular/router';
import {MatFormFieldModule} from '@angular/material/form-field';
interface jobsdataarry {   
  Experiance: Number;  
  jobtype: String;  
  place: String;  
  skills: String;  
  jobfuction:string;  
  location:string;
  salary:number;
}  
const routes: Routes = [];
@Component({
  selector: 'app-parentcomponent',
  templateUrl: './parentcomponent.component.html',
  styleUrls: ['./parentcomponent.component.css']
})

export class ParentcomponentComponent implements OnInit {
  
  @Input()
  dataofjobs: jobsdataarry[] = parentdatajson;  
  data: string | undefined;
  // countrytable:boolean=false;
  // studenttable:boolean=false;
  // public countryList:{name:string, role:string}[] = countries;
  // public studentlist:{id:number,name:string,email:string,gender:string}[]=manju;

 

  todayNumber: number = Date.now();
  todayDate : Date = new Date();
  todayString : string = new Date().toDateString();
  todayISOString : string = new Date().toISOString();


  


  constructor() { }

  ngOnInit(): void {



 
  }


 


}

