import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BabycomponentComponent } from './babycomponent.component';

describe('BabycomponentComponent', () => {
  let component: BabycomponentComponent;
  let fixture: ComponentFixture<BabycomponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BabycomponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BabycomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
