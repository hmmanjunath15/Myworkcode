import { Component, OnInit } from '@angular/core';
import customerdata  from './customerdata.json'
// import {MatFormFieldModule} from '@angular/material/form-field';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
interface customer {   
  id: Number;  
  name: String;  
  email: String;  
  gender: String;  
}  
@Component({ 
  selector: 'app-babycomponent',
  templateUrl: './babycomponent.component.html',
  styleUrls: ['./babycomponent.component.css']
})

export class BabycomponentComponent implements OnInit {



  
constructor(){}

ngOnInit(){}

 

// resolved(captchaResponse: string) {
//   console.log(`Resolved captcha with response: ${captchaResponse}`);
// }



}




