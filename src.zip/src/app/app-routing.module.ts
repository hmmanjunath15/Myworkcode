import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ParentcomponentComponent } from './parentcomponent/parentcomponent.component';
import { BabycomponentComponent } from './babycomponent/babycomponent.component';
import { HeaderComponent } from './header/header.component';
const routes: Routes = [
  {path:'',component: ParentcomponentComponent },
  {path:'babycomponent' ,component: BabycomponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
export const routingcomponents = [ParentcomponentComponent, BabycomponentComponent, HeaderComponent]
